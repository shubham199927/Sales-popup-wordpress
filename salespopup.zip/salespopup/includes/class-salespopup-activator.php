<?php

/**
 * Fired during plugin activation
 *
 * @link       https://www.instagram.com/theycallmeshubham/
 * @since      1.0.0
 *
 * @package    Salespopup
 * @subpackage Salespopup/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Salespopup
 * @subpackage Salespopup/includes
 * @author     Shubham sharma <shubhamshivay@gmail.com>
 */
class Salespopup_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
