<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://www.instagram.com/theycallmeshubham/
 * @since      1.0.0
 *
 * @package    Salespopup
 * @subpackage Salespopup/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Salespopup
 * @subpackage Salespopup/includes
 * @author     Shubham sharma <shubhamshivay@gmail.com>
 */
class Salespopup_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
