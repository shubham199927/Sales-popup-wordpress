jQuery(document).ready(function($) {
    // Check if user has seen the popup in this session
    if (!sessionStorage.getItem('popupShown')) {
        setTimeout(function() {
            $('.popup-overlay').fadeIn();
        }, 3000); // Show popup after 3 seconds

        // Set flag in sessionStorage
        sessionStorage.setItem('popupShown', 'true');
    }

    // Close button functionality
    $('.popup-close').on('click', function() {
        $('.popup-overlay').fadeOut();
    });

    // Close on overlay click
    $('.popup-overlay').on('click', function(e) {
        if (e.target === this) {
            $(this).fadeOut();
        }
    });
});
