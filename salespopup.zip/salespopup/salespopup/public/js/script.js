jQuery(document).ready(function($) {
    // Check if user has seen the popup before
    if (!localStorage.getItem('popupShown')) {
        setTimeout(function() {
            $('.popup-overlay').fadeIn();
        }, 3000); // Show popup after 3 seconds

        // Set flag in localStorage
        localStorage.setItem('popupShown', 'true');
    }

    // Close button functionality
    $('.popup-close').on('click', function() {
        $('.popup-overlay').fadeOut();
    });

    // Close on overlay click
    $('.popup-overlay').on('click', function(e) {
        if (e.target === this) {
            $(this).fadeOut();
        }
    });
});
