<?php

/**
 * The plugin bootstrap file
 *
 * This file is read by WordPress to generate the plugin information in the plugin
 * admin area. This file also includes all of the dependencies used by the plugin,
 * registers the activation and deactivation functions, and defines a function
 * that starts the plugin.
 *
 * @link              https://www.instagram.com/theycallmeshubham/
 * @since             1.0.0
 * @package           Salespopup
 *
 * @wordpress-plugin
 * Plugin Name:       Sales Popup
 * Plugin URI:        https://www.linkedin.com/in/webdev-shubham/
 * Description:       Plugin to show a simple sales popup on website
 * Version:           1.0.0
 * Author:            Shubham sharma
 * Author URI:        https://www.instagram.com/theycallmeshubham//
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       salespopup
 * Domain Path:       /languages
 */

// If this file is called directly, abort.
if ( ! defined( 'WPINC' ) ) {
	die;
}

/**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */

 function salespopup_enqueue_scripts() {
    wp_enqueue_style('salespopup-style', plugin_dir_url(__FILE__) . 'public/css/style.css');
    wp_enqueue_script('salespopup-script', plugin_dir_url(__FILE__) . 'public/js/script.js', array('jquery'), '1.0', true);
}
add_action('wp_enqueue_scripts', 'salespopup_enqueue_scripts');

function salespopup_html() {
    ?>
    <div class="popup-overlay">
        <div class="popup-container">
            <span class="popup-close">&times;</span>
            <h2 class="popup-title">Welcome to Our Store! 🎉</h2>
            <div class="popup-content">
                <p>Buy Any Three Perfumes At 999!</p>
            </div>
            <button class="cta-button" onclick="window.location.href='/shop'">Shop Now</button>
        </div>
    </div>
    <?php
}
add_action('wp_footer', 'salespopup_html');
?>
